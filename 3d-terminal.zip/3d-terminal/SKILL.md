---
name: 3d-terminal
description: Development helper for the 3D Terminal Placement feature in MTT Container Terminal. This skill should be used when working on Three.js 3D visualization, container placement logic, or the placement API endpoints. Triggers on tasks involving 3D yard layout, container positioning, InstancedMesh rendering, or extending the placement feature.
---

# 3D Terminal Planner - Expert Development Guide

## Overview

This skill provides **expert guidance** for developing the 3D Terminal Placement feature. It combines:

1. **Development assistance** - Code patterns, file navigation, workflows
2. **3D visualization expertise** - Three.js best practices, rendering optimization
3. **Design guidance** - Professional terminal UI/UX, visual consistency
4. **Industry knowledge** - Standards from NAVIS N4, Tideworks, Cosmos TOS

When assisting with 3D terminal tasks, act as an **expert consultant** who ensures functionality, appearance, and design are professional-grade and consistent.

---

## Design Philosophy

### Core Principles

| Principle | Description |
|-----------|-------------|
| **Clarity** | Every visual element must communicate meaning instantly |
| **Consistency** | Same colors, sizes, and interactions everywhere |
| **Performance** | 60fps minimum, even with 2000+ containers |
| **Professional** | Match quality of industry TOS systems |

### Visual Hierarchy

```
1. MOST IMPORTANT: Selected container (brightest, largest visual weight)
2. HIGH: Hovered container (highlighted but not dominant)
3. MEDIUM: Status differentiation (laden vs empty)
4. LOW: Grid, zone labels, background elements
```

---

## Visual Design System

### Color Palette

**Primary Colors (Container Status)**
| Status | Color | Hex | RGB | Usage |
|--------|-------|-----|-----|-------|
| Laden (Full) | Green | `#52c41a` | `82, 196, 26` | Default laden container |
| Empty | Blue | `#1677ff` | `22, 119, 255` | Default empty container |
| Hovered | Orange | `#fa8c16` | `250, 140, 22` | Mouse hover state |
| Selected | Gold | `#faad14` | `250, 173, 20` | Active selection |
| Error/Blocked | Red | `#f5222d` | `245, 34, 45` | Invalid position |

**Dwell Time Heatmap** (when enabled)
| Days | Color | Hex | Meaning |
|------|-------|-----|---------|
| 0-3 | Green | `#52c41a` | Fresh - just arrived |
| 4-7 | Yellow | `#fadb14` | Normal dwell |
| 8-14 | Orange | `#fa8c16` | Aging - needs attention |
| 15-21 | Red | `#f5222d` | Overdue - action required |
| 21+ | Purple | `#722ed1` | Critical - escalate |

**Scene Colors**
| Element | Color | Hex | Notes |
|---------|-------|-----|-------|
| Background | Dark Navy | `#1a1a2e` | Low contrast, eye-friendly |
| Ground Plane | Dark Gray | `#2d2d44` | Subtle, doesn't compete |
| Grid Lines | Gray | `#444444` | Barely visible, reference only |
| Zone Labels | White | `#ffffff` | High contrast for readability |
| Zone Boundaries | Cyan | `#13c2c2` | Distinct but not harsh |

### Material Guidelines

**Container Materials**
```typescript
// USE: MeshLambertMaterial for performance with many instances
// Provides diffuse lighting without expensive specular calculations
const material = new THREE.MeshLambertMaterial({
  color: 0x52c41a,
  // NO metalness/roughness (not supported)
});

// AVOID: MeshStandardMaterial for containers (too expensive)
// Only use for special highlight effects on single objects
```

**Material Consistency Rules**
1. All containers use `MeshLambertMaterial` (performance)
2. Ground plane uses `MeshBasicMaterial` (no lighting needed)
3. Selection highlight can use `MeshStandardMaterial` with emissive
4. Never mix material types for same object category

### Lighting Setup

**Three-Point Lighting (Professional Standard)**
```typescript
// Ambient: Soft fill to prevent pure black shadows
const ambient = new THREE.AmbientLight(0xffffff, 0.5);

// Key Light: Main directional light from upper-front
const keyLight = new THREE.DirectionalLight(0xffffff, 0.8);
keyLight.position.set(50, 100, 50);

// Fill Light: Softer, from opposite side
const fillLight = new THREE.DirectionalLight(0xffffff, 0.3);
fillLight.position.set(-50, 50, -50);

// Optional: Rim light for depth perception
const rimLight = new THREE.DirectionalLight(0xffffff, 0.2);
rimLight.position.set(0, 50, -100);
```

**Lighting Rules**
- Total intensity should not exceed 1.8 (ambient + directional)
- Key light always from upper-right quadrant (consistent shadows)
- Avoid colored lights (keep professional, neutral)

### Shadow Guidelines

**When to Enable Shadows**
- Enable for: Selected container, crane/equipment models
- Disable for: InstancedMesh containers (performance)
- Ground shadow: Use simple circular decal, not real-time shadow

```typescript
// Shadow for selected container only
selectedMesh.castShadow = true;
groundPlane.receiveShadow = true;

// Shadow map settings
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
```

---

## Layout Design

### Zone Layout (Recommended)

```
┌─────────────────────────────────────────────────────────────────┐
│                        ENTRY/EXIT GATE                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐           │
│  │   ZONE A    │   │   ZONE B    │   │   ZONE C    │   TRUCK   │
│  │   General   │   │   General   │   │   Reefer    │   LANE    │
│  │   10×10×4   │   │   10×10×4   │   │   10×10×4   │    ↓      │
│  └─────────────┘   └─────────────┘   └─────────────┘           │
│                                                                  │
│  ┌─────────────┐   ┌─────────────┐                              │
│  │   ZONE D    │   │   ZONE E    │   ← Equipment staging       │
│  │   Import    │   │   Hazmat    │                              │
│  │   10×10×4   │   │   10×10×4   │                              │
│  └─────────────┘   └─────────────┘                              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Spacing Constants

```typescript
// Standard ISO container dimensions (meters)
const CONTAINER_20FT = { length: 6.058, width: 2.438, height: 2.591 };
const CONTAINER_40FT = { length: 12.192, width: 2.438, height: 2.591 };

// Yard spacing (professional standards)
const BAY_SPACING = 6.5;     // Gap between containers (length direction)
const ROW_SPACING = 3.0;     // Gap between rows (width direction)
const TIER_HEIGHT = 2.7;     // Vertical spacing per tier
const ZONE_GAP = 15.0;       // Gap between zones (for equipment access)
const TRUCK_LANE_WIDTH = 12.0; // Standard truck lane

// Camera defaults
const DEFAULT_CAMERA_HEIGHT = 150;  // Bird's-eye view height
const MIN_ZOOM = 0.5;               // Maximum zoom out
const MAX_ZOOM = 4.0;               // Maximum zoom in
```

### Zone Visual Differentiation

```typescript
// Each zone should have subtle visual distinction
const ZONE_COLORS = {
  A: { base: 0x52c41a, accent: 0x73d13d },  // Green - General
  B: { base: 0x1677ff, accent: 0x4096ff },  // Blue - General
  C: { base: 0x13c2c2, accent: 0x36cfc9 },  // Cyan - Reefer
  D: { base: 0x722ed1, accent: 0x9254de },  // Purple - Import
  E: { base: 0xf5222d, accent: 0xff4d4f },  // Red - Hazmat
};

// Zone boundary styling
function createZoneBoundary(zone: string) {
  const geometry = new THREE.BufferGeometry();
  // Create dashed line rectangle
  const material = new THREE.LineDashedMaterial({
    color: ZONE_COLORS[zone].accent,
    dashSize: 2,
    gapSize: 1,
    linewidth: 2,
  });
  // ...
}
```

---

## Consistency Guidelines

### Naming Conventions

**Files**
| Type | Pattern | Example |
|------|---------|---------|
| Vue Components | PascalCase | `TerminalLayout3D.vue` |
| Composables | camelCase with `use` prefix | `useContainerMesh.ts` |
| Services | camelCase with `Service` suffix | `placementService.ts` |
| Types | PascalCase | `ContainerPlacement` |

**Three.js Objects**
```typescript
// Always name objects for debugging
mesh.name = 'container_123';
group.name = 'zone_A';
light.name = 'keyLight';
```

**CSS/Styling**
- Use CSS variables for all colors: `var(--container-laden)`
- Component-scoped styles with `<style scoped>`
- Ant Design Vue tokens for UI consistency

### Interaction Patterns

**Hover Behavior**
1. Mouse enters container → Orange highlight (instant)
2. Tooltip appears after 200ms delay
3. Mouse leaves → Return to original color (instant)

**Selection Behavior**
1. Click container → Gold highlight + pulse animation
2. Details panel opens
3. Click elsewhere → Deselect

**Animation Guidelines**
| Animation | Duration | Easing |
|-----------|----------|--------|
| Hover highlight | 0ms | Instant |
| Selection pulse | 300ms | ease-out |
| Camera transition | 800ms | ease-in-out |
| Container place | 500ms | bounce |
| Tooltip fade | 150ms | ease |

```typescript
// Use GSAP for smooth animations
import gsap from 'gsap';

function animateSelection(mesh: THREE.Mesh) {
  gsap.to(mesh.scale, {
    x: 1.05, y: 1.05, z: 1.05,
    duration: 0.15,
    yoyo: true,
    repeat: 1,
    ease: 'power2.out'
  });
}
```

### UI Component Consistency

**Panel Layout**
```
┌──────────────────────────────────────────────────────┐
│ [Icon] Panel Title                        [?] [×]   │  ← Header: 48px
├──────────────────────────────────────────────────────┤
│                                                      │
│  Content Area                                        │  ← Body: flex
│  - Use 16px padding                                  │
│  - 8px gap between elements                          │
│  - Ant Design components only                        │
│                                                      │
├──────────────────────────────────────────────────────┤
│ [Secondary Action]              [Primary Action]     │  ← Footer: 56px
└──────────────────────────────────────────────────────┘
```

**Button Hierarchy**
1. **Primary**: Main action (place container, confirm)
2. **Default**: Secondary actions (cancel, reset)
3. **Text**: Tertiary actions (help, details)
4. **Danger**: Destructive actions (remove, delete)

---

## Professional TOS Reference

### Industry Standards (NAVIS N4, Tideworks)

**Features to Match**
| Feature | Implementation |
|---------|---------------|
| Real-time yard view | WebSocket updates |
| Container search | Type-ahead with highlighting |
| Move preview | Ghost container with validation |
| Audit trail | All movements logged |
| Multi-user | Conflict resolution UI |

**Visual Standards**
- Clean, minimal UI (no clutter)
- High contrast for outdoor use
- Keyboard shortcuts for power users
- Status bar with live stats

### Container Information Display

**Tooltip Content** (on hover)
```
┌─────────────────────────────────┐
│ HDMU6565958                     │  ← Container number (bold)
│ 42G1 • Laden                    │  ← ISO type • Status
│ Position: A-R03-B15-T2          │  ← Current position
│ Dwell: 5 days                   │  ← Dwell time
│ Company: ABC Logistics          │  ← Owner
└─────────────────────────────────┘
```

**Detail Panel** (on selection)
- Full container entry details
- Movement history
- Related pre-orders
- Available actions (move, remove)

---

## Quick Reference

### Key Files

**Frontend (Vue 3 + Three.js)**
| File | Purpose |
|------|---------|
| `frontend/src/views/ContainerPlacement.vue` | Main page component |
| `frontend/src/components/TerminalLayout3D.vue` | Three.js 3D canvas component |
| `frontend/src/components/PlacementPanel.vue` | Controls and filters panel |
| `frontend/src/composables/use3DScene.ts` | Scene, camera, renderer setup |
| `frontend/src/composables/useContainerMesh.ts` | InstancedMesh container rendering |
| `frontend/src/composables/usePlacementState.ts` | Shared state (selection, layout data) |
| `frontend/src/services/placementService.ts` | API client for placement endpoints |
| `frontend/src/types/placement.ts` | TypeScript interfaces |

**Backend (Django DRF)**
| File | Purpose |
|------|---------|
| `backend/apps/terminal_operations/models.py` | `ContainerPosition` model |
| `backend/apps/terminal_operations/services/placement_service.py` | Business logic |
| `backend/apps/terminal_operations/serializers.py` | Position serializers |
| `backend/apps/terminal_operations/views.py` | `PlacementViewSet` |
| `backend/apps/terminal_operations/urls.py` | API routes |

**Documentation**
| File | Purpose |
|------|---------|
| `PLAN-3D-TERMINAL.md` | Original implementation plan |
| `IMPROVEMENTS-3D-TERMINAL.md` | Professional enhancements roadmap |

### Terminal Configuration

```
Zones: A, B, C, D, E (5 zones)
Rows per zone: 10
Bays per zone: 10
Max tiers: 4
Total capacity: ~2000 TEU
Position format: A-R03-B15-T2 (Zone-Row-Bay-Tier)
```

### API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/terminal/placement/layout/` | Full 3D layout data |
| POST | `/api/terminal/placement/suggest/` | Auto-suggest position |
| POST | `/api/terminal/placement/assign/` | Assign container to position |
| PATCH | `/api/terminal/placement/{id}/move/` | Move container |
| DELETE | `/api/terminal/placement/{id}/` | Remove position |
| GET | `/api/terminal/placement/available/` | List available positions |

---

## Development Workflows

### Adding a New Three.js Feature

1. **Read existing composables** first to understand the pattern:
   ```
   frontend/src/composables/use3DScene.ts
   frontend/src/composables/useContainerMesh.ts
   ```

2. **Create new composable** following the naming pattern `use<Feature>.ts`:
   ```typescript
   export function useNewFeature(scene: Ref<THREE.Scene | undefined>) {
     const state = ref<SomeType>();

     function doSomething() { /* ... */ }
     function dispose() { /* Cleanup THREE resources */ }

     return { state, doSomething, dispose };
   }
   ```

3. **Follow design guidelines** from this document for colors, materials, animations

4. **Integrate in TerminalLayout3D.vue**:
   - Import and use the composable
   - Call `dispose()` in `onUnmounted`
   - Add any UI controls to PlacementPanel.vue

### Implementing Visual Improvements

When improving appearance:

1. **Check consistency** with existing color palette
2. **Test contrast** - can colors be distinguished?
3. **Verify performance** - maintain 60fps
4. **Match professional standards** - reference NAVIS/Tideworks screenshots

### Debugging 3D Rendering

| Issue | Solution |
|-------|----------|
| Containers not visible | Check camera position, near/far planes |
| Black screen | Verify WebGL context, check console for errors |
| Performance slow | Use InstancedMesh, check draw calls |
| Raycasting not working | Verify mesh is in intersect array |
| Memory leaks | Ensure `dispose()` called on unmount |

---

## Stacking Rules

1. **Max height**: 4 tiers
2. **Support required**: Tier > 1 must have container below
3. **Weight distribution** (improvement): Laden below Empty
4. **Size compatibility** (improvement): Same or smaller on top

Validation happens in `PlacementService.validate_stacking()`.

---

## Testing

**Backend tests**:
```bash
cd backend && .venv/bin/pytest apps/terminal_operations/tests/ -v
```

**Frontend type checking**:
```bash
cd frontend && npm run build
```

**Manual 3D testing checklist**:
- [ ] Containers render in correct positions
- [ ] Click selects container
- [ ] Hover shows visual feedback
- [ ] Camera controls work (zoom, pan, rotate)
- [ ] Table ↔ 3D sync works
- [ ] Auto-suggest returns valid position
- [ ] Position assignment persists
- [ ] Colors match design system
- [ ] 60fps performance maintained

---

## Resources

- **references/architecture.md** - Detailed architecture patterns and decisions
- **PLAN-3D-TERMINAL.md** - Original implementation plan (in project root)
- **IMPROVEMENTS-3D-TERMINAL.md** - Professional enhancements roadmap (in project root)
