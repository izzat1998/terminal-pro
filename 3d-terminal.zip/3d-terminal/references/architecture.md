# 3D Terminal Architecture Reference

This document provides detailed architectural patterns and decisions for the 3D Terminal Placement feature.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         ContainerPlacement.vue                       │
│                           (Page Component)                           │
├────────────────────────┬────────────────────────────────────────────┤
│    PlacementPanel.vue  │            TerminalLayout3D.vue            │
│    (Controls/Filters)  │            (Three.js Canvas)               │
│                        │                                             │
│  ┌──────────────────┐  │  ┌────────────────────────────────────────┐│
│  │ Zone Filter      │  │  │  use3DScene.ts                         ││
│  │ Auto-Suggest Btn │  │  │  - Scene, Camera, Renderer             ││
│  │ Stats Display    │  │  │  - Lighting, GridHelper                ││
│  └──────────────────┘  │  │  - OrbitControls                       ││
│                        │  └────────────────────────────────────────┘│
│                        │  ┌────────────────────────────────────────┐│
│                        │  │  useContainerMesh.ts                   ││
│                        │  │  - InstancedMesh (laden/empty)         ││
│                        │  │  - Matrix transforms                   ││
│                        │  │  - Color updates                       ││
│                        │  └────────────────────────────────────────┘│
│                        │  ┌────────────────────────────────────────┐│
│                        │  │  Raycasting (click/hover)              ││
│                        │  │  - Container selection                 ││
│                        │  │  - Tooltip display                     ││
│                        │  └────────────────────────────────────────┘│
└────────────────────────┴────────────────────────────────────────────┘
                                    │
                    usePlacementState.ts (Shared State)
                    - selectedContainerId
                    - hoveredContainerId
                    - layout data
                    - API operations
                                    │
                    placementService.ts (API Client)
                                    │
                            HTTP/REST API
                                    │
┌───────────────────────────────────────────────────────────────────┐
│                     Django Backend                                 │
│  ┌─────────────────────────────────────────────────────────────┐  │
│  │  PlacementViewSet (views.py)                                 │  │
│  │  - layout()      GET  /layout/                               │  │
│  │  - suggest()     POST /suggest/                              │  │
│  │  - assign()      POST /assign/                               │  │
│  │  - move()        PATCH /{id}/move/                           │  │
│  │  - destroy()     DELETE /{id}/                               │  │
│  │  - available()   GET  /available/                            │  │
│  └─────────────────────────────────────────────────────────────┘  │
│                            │                                       │
│  ┌─────────────────────────▼───────────────────────────────────┐  │
│  │  PlacementService (placement_service.py)                     │  │
│  │  - get_layout()                                              │  │
│  │  - suggest_position()                                        │  │
│  │  - assign_position()                                         │  │
│  │  - move_container()                                          │  │
│  │  - remove_position()                                         │  │
│  │  - validate_stacking()                                       │  │
│  └─────────────────────────────────────────────────────────────┘  │
│                            │                                       │
│  ┌─────────────────────────▼───────────────────────────────────┐  │
│  │  Models (models.py)                                          │  │
│  │  - ContainerPosition (1:1 with ContainerEntry)               │  │
│  │    - zone, row, bay, tier                                    │  │
│  │    - auto_assigned flag                                      │  │
│  │    - coordinate_string property                              │  │
│  └─────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────────────┘
```

## Three.js Patterns

### Scene Setup Pattern

```typescript
// use3DScene.ts pattern
export function use3DScene(canvasRef: Ref<HTMLCanvasElement | undefined>) {
  // Use shallowRef for Three.js objects (no deep reactivity needed)
  const scene = shallowRef<THREE.Scene>();
  const camera = shallowRef<THREE.OrthographicCamera>();
  const renderer = shallowRef<THREE.WebGLRenderer>();
  const controls = shallowRef<OrbitControls>();

  function initScene() {
    if (!canvasRef.value) return;

    // Scene
    scene.value = new THREE.Scene();
    scene.value.background = new THREE.Color(0x1a1a2e);

    // Camera (orthographic for bird's-eye view)
    const aspect = canvasRef.value.clientWidth / canvasRef.value.clientHeight;
    const frustum = 100;
    camera.value = new THREE.OrthographicCamera(
      -frustum * aspect, frustum * aspect,
      frustum, -frustum,
      0.1, 1000
    );
    camera.value.position.set(0, 150, 0);
    camera.value.lookAt(0, 0, 0);

    // Renderer
    renderer.value = new THREE.WebGLRenderer({
      canvas: canvasRef.value,
      antialias: true
    });
    renderer.value.setPixelRatio(window.devicePixelRatio);

    // Controls
    controls.value = new OrbitControls(camera.value, canvasRef.value);
    controls.value.enableRotate = false; // Bird's-eye only
    controls.value.enablePan = true;
    controls.value.enableZoom = true;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(50, 100, 50);
    scene.value.add(ambientLight, directionalLight);

    // Grid
    const grid = new THREE.GridHelper(200, 50, 0x444444, 0x333333);
    grid.rotation.x = Math.PI / 2; // Rotate to XZ plane
    scene.value.add(grid);
  }

  function animate() {
    if (!renderer.value || !scene.value || !camera.value) return;
    requestAnimationFrame(animate);
    controls.value?.update();
    renderer.value.render(scene.value, camera.value);
  }

  function dispose() {
    // CRITICAL: Always dispose Three.js resources
    controls.value?.dispose();
    renderer.value?.dispose();
    scene.value?.traverse((object) => {
      if (object instanceof THREE.Mesh) {
        object.geometry.dispose();
        if (Array.isArray(object.material)) {
          object.material.forEach(m => m.dispose());
        } else {
          object.material.dispose();
        }
      }
    });
  }

  return { scene, camera, renderer, controls, initScene, animate, dispose };
}
```

### InstancedMesh Pattern

```typescript
// useContainerMesh.ts pattern
// InstancedMesh is CRITICAL for performance - renders 1000s of containers in 1 draw call

export function useContainerMesh(scene: Ref<THREE.Scene | undefined>) {
  const ladenMesh = shallowRef<THREE.InstancedMesh>();
  const emptyMesh = shallowRef<THREE.InstancedMesh>();
  const containerMap = new Map<number, { mesh: THREE.InstancedMesh; index: number }>();

  const MAX_INSTANCES = 1500; // Per mesh type

  function initMeshes() {
    if (!scene.value) return;

    // Container geometry (standard 20ft container)
    const geometry = new THREE.BoxGeometry(2.4, 2.6, 6.1);

    // Materials
    const ladenMaterial = new THREE.MeshLambertMaterial({ color: 0x52c41a });
    const emptyMaterial = new THREE.MeshLambertMaterial({ color: 0x1677ff });

    // Create instanced meshes
    ladenMesh.value = new THREE.InstancedMesh(geometry, ladenMaterial, MAX_INSTANCES);
    emptyMesh.value = new THREE.InstancedMesh(geometry, emptyMaterial, MAX_INSTANCES);

    // Hide all instances initially
    ladenMesh.value.count = 0;
    emptyMesh.value.count = 0;

    scene.value.add(ladenMesh.value, emptyMesh.value);
  }

  function updateContainers(containers: ContainerPlacement[]) {
    if (!ladenMesh.value || !emptyMesh.value) return;

    containerMap.clear();
    let ladenIndex = 0;
    let emptyIndex = 0;
    const matrix = new THREE.Matrix4();

    containers.forEach((container) => {
      // Calculate world position from zone/row/bay/tier
      const worldPos = positionToWorld(container.position);
      matrix.setPosition(worldPos.x, worldPos.y, worldPos.z);

      const mesh = container.status === 'LADEN' ? ladenMesh.value! : emptyMesh.value!;
      const index = container.status === 'LADEN' ? ladenIndex++ : emptyIndex++;

      mesh.setMatrixAt(index, matrix);
      containerMap.set(container.id, { mesh, index });
    });

    // Update counts and notify GPU
    ladenMesh.value.count = ladenIndex;
    emptyMesh.value.count = emptyIndex;
    ladenMesh.value.instanceMatrix.needsUpdate = true;
    emptyMesh.value.instanceMatrix.needsUpdate = true;
  }

  function highlightContainer(id: number, color: number) {
    const entry = containerMap.get(id);
    if (!entry) return;

    // InstancedMesh supports per-instance colors
    entry.mesh.setColorAt(entry.index, new THREE.Color(color));
    entry.mesh.instanceColor!.needsUpdate = true;
  }

  return { initMeshes, updateContainers, highlightContainer, containerMap };
}
```

### Position Coordinate System

```typescript
// Converting grid position to world coordinates
// Zone layout (top view):
//
//   Z (row)
//   ↑
//   │  ┌─────┐ ┌─────┐ ┌─────┐
//   │  │  A  │ │  B  │ │  C  │
//   │  └─────┘ └─────┘ └─────┘
//   │  ┌─────┐ ┌─────┐
//   │  │  D  │ │  E  │
//   │  └─────┘ └─────┘
//   └──────────────────────────→ X (bay)

const ZONE_OFFSETS: Record<string, { x: number; z: number }> = {
  A: { x: -70, z: 40 },
  B: { x: 0, z: 40 },
  C: { x: 70, z: 40 },
  D: { x: -35, z: -40 },
  E: { x: 35, z: -40 },
};

const BAY_SPACING = 6.5;    // Distance between bays
const ROW_SPACING = 3.0;    // Distance between rows
const TIER_HEIGHT = 2.7;    // Height per tier

function positionToWorld(pos: Position): THREE.Vector3 {
  const zoneOffset = ZONE_OFFSETS[pos.zone];
  return new THREE.Vector3(
    zoneOffset.x + (pos.bay - 1) * BAY_SPACING,
    (pos.tier - 1) * TIER_HEIGHT + TIER_HEIGHT / 2,  // Center of container
    zoneOffset.z + (pos.row - 1) * ROW_SPACING
  );
}
```

## Backend Service Pattern

```python
# placement_service.py pattern
from apps.terminal_operations.services.base import BaseService
from apps.terminal_operations.exceptions import BusinessLogicError

class PlacementService(BaseService):
    """
    Business logic for container placement operations.
    All placement-related logic lives here, NOT in views.
    """

    def suggest_position(
        self,
        container_entry_id: int,
        zone_preference: str | None = None
    ) -> dict:
        """
        Auto-suggest optimal position for a container.

        Args:
            container_entry_id: ID of the container entry to place
            zone_preference: Optional preferred zone (A-E)

        Returns:
            dict with suggested_position, reason, and alternatives

        Raises:
            BusinessLogicError: If no positions available or container not found
        """
        container_entry = self._get_container_entry(container_entry_id)

        # Check if already placed
        if hasattr(container_entry, 'position'):
            raise BusinessLogicError(
                code="ALREADY_PLACED",
                message="Контейнер уже размещён"
            )

        # Find optimal position
        zone, row, bay, tier = self._find_optimal_position(zone_preference)

        # Get alternatives
        alternatives = self._find_alternatives(zone, row, bay, tier, limit=3)

        return {
            'suggested_position': {
                'zone': zone,
                'row': row,
                'bay': bay,
                'tier': tier,
                'coordinate': f"{zone}-R{row:02d}-B{bay:02d}-T{tier}"
            },
            'reason': self._build_reason(zone, row, bay, tier, zone_preference),
            'alternatives': alternatives
        }

    def validate_stacking(
        self,
        zone: str,
        row: int,
        bay: int,
        tier: int
    ) -> tuple[bool, list[str]]:
        """
        Validate stacking rules for a position.

        Returns:
            (is_valid, list_of_violations)
        """
        violations = []

        # Rule 1: Max tier
        if tier > 4:
            violations.append("MAX_TIER: Максимум 4 яруса")

        # Rule 2: Support required for tier > 1
        if tier > 1:
            below_exists = ContainerPosition.objects.filter(
                zone=zone, row=row, bay=bay, tier=tier - 1
            ).exists()
            if not below_exists:
                violations.append("NO_SUPPORT: Нет контейнера ниже для поддержки")

        return len(violations) == 0, violations
```

## State Management Pattern

```typescript
// usePlacementState.ts pattern
// Shared reactive state for table ↔ 3D synchronization

export function usePlacementState() {
  // Selection state (shared between table and 3D view)
  const selectedContainerId = ref<number | null>(null);
  const hoveredContainerId = ref<number | null>(null);

  // Layout data
  const layout = ref<PlacementLayout | null>(null);
  const loading = ref(false);
  const error = ref<string | null>(null);

  // Computed
  const placedContainers = computed(() =>
    layout.value?.containers ?? []
  );

  const unplacedContainers = computed(() =>
    layout.value?.unplaced ?? []
  );

  const zoneStats = computed(() =>
    layout.value?.stats.by_zone ?? {}
  );

  // Actions
  async function fetchLayout() {
    loading.value = true;
    error.value = null;
    try {
      layout.value = await placementService.getLayout();
    } catch (e) {
      error.value = (e as Error).message;
    } finally {
      loading.value = false;
    }
  }

  async function suggestPosition(entryId: number, zonePreference?: string) {
    return placementService.suggestPosition(entryId, zonePreference);
  }

  async function assignPosition(entryId: number, position: Position) {
    const result = await placementService.assignPosition(entryId, position);
    // Refresh layout to reflect change
    await fetchLayout();
    return result;
  }

  // Watch for selection changes and emit events
  watch(selectedContainerId, (newId, oldId) => {
    // Emit custom events for cross-component communication
    window.dispatchEvent(new CustomEvent('container-selected', {
      detail: { newId, oldId }
    }));
  });

  return {
    selectedContainerId,
    hoveredContainerId,
    layout,
    loading,
    error,
    placedContainers,
    unplacedContainers,
    zoneStats,
    fetchLayout,
    suggestPosition,
    assignPosition,
  };
}
```

## TypeScript Interfaces

```typescript
// types/placement.ts

export type ZoneCode = 'A' | 'B' | 'C' | 'D' | 'E';

export interface Position {
  zone: ZoneCode;
  row: number;  // 1-10
  bay: number;  // 1-10
  tier: number; // 1-4
  coordinate?: string; // "A-R03-B15-T2"
}

export interface ContainerPlacement {
  id: number;
  container_entry: number;
  container_number: string;
  iso_type: string;
  status: 'LADEN' | 'EMPTY';
  position: Position;
  entry_time: string;
  dwell_time_days: number;
  company_name: string;
}

export interface UnplacedContainer {
  id: number;
  container_number: string;
  iso_type: string;
  status: 'LADEN' | 'EMPTY';
  entry_time: string;
  company_name: string;
}

export interface PlacementLayout {
  zones: ZoneCode[];
  dimensions: {
    max_rows: number;
    max_bays: number;
    max_tiers: number;
  };
  containers: ContainerPlacement[];
  unplaced: UnplacedContainer[];
  stats: {
    total_capacity: number;
    occupied: number;
    available: number;
    by_zone: Record<ZoneCode, { occupied: number; available: number }>;
  };
}

export interface SuggestionResponse {
  success: boolean;
  suggested_position: Position;
  reason: string;
  alternatives: Position[];
}
```

## Error Handling

### Backend Errors

```python
# exceptions.py
class PlacementError(BusinessLogicError):
    """Base class for placement-specific errors."""
    pass

# Error codes
POSITION_OCCUPIED = "POSITION_OCCUPIED"  # Position already has a container
NO_SUPPORT = "NO_SUPPORT"                # Tier > 1 without container below
MAX_TIER = "MAX_TIER"                    # Tier exceeds maximum (4)
ALREADY_PLACED = "ALREADY_PLACED"        # Container already has a position
NO_POSITIONS = "NO_POSITIONS"            # No available positions
```

### Frontend Error Handling

```typescript
// placementService.ts
import { message } from 'ant-design-vue';

const ERROR_MESSAGES: Record<string, string> = {
  POSITION_OCCUPIED: 'Эта позиция уже занята',
  NO_SUPPORT: 'Нет контейнера ниже для поддержки',
  MAX_TIER: 'Максимум 4 яруса',
  ALREADY_PLACED: 'Контейнер уже размещён',
  NO_POSITIONS: 'Нет свободных позиций',
};

function handlePlacementError(error: unknown) {
  if (axios.isAxiosError(error) && error.response?.data?.code) {
    const code = error.response.data.code;
    const msg = ERROR_MESSAGES[code] || error.response.data.message;
    message.error(msg);
  } else {
    message.error('Произошла ошибка');
  }
}
```

## Performance Considerations

### Frontend Optimization

1. **InstancedMesh** - Single draw call for all containers of same type
2. **shallowRef** - No deep reactivity for Three.js objects
3. **Throttled raycasting** - Don't raycast on every mouse move
4. **Lazy loading** - Code-split the 3D view component
5. **Dispose on unmount** - Always clean up WebGL resources

### Backend Optimization

1. **Database indexes** on `(zone, row, bay, tier)` for fast lookups
2. **select_related** for efficient joins with ContainerEntry
3. **Bulk operations** for stats calculations
4. **Caching** layout data if it doesn't change frequently
